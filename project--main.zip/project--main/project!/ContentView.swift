//
//  ContentView.swift
//  project!
//
//  Created by 許雯淇 on 2022/12/19.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        homeView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
